const nodes = [
    {
      id: '1',
      data: { label: 'Hello' },
      position: { x: 0, y: 100 },
      type: 'input',
    },
    {
      id: '2',
      data: { label: 'World' },
      position: { x: 0, y: 150 },
    },
    {
      id: '3',
      data: { label: 'World' },
      position: { x: 0, y: 200 },
    },
    {
      id: '4',
      data: { label: 'World' },
      position: { x: 0, y: 250 },
    },
    {
      id: '5',
      data: { label: 'World' },
      position: { x: 0, y: 300 },
    },
  ];

  export default nodes